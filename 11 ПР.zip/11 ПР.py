from tkinter import *
from tkinter import scrolledtext
import json
import requests
from pprint import pprint

window = Tk()
window.title("Прохоренко Андрей Владиславович")
window.geometry("400x300")
window.resizable(False, False)

inputName=Entry(window,width=50)
inputName.grid(column=1, row=1, padx = 10, pady = 10)
inputName.focus()
inputName.insert(0,"ansible")

def applyBtnOnClick():
    outputField.delete(1.0,END)
    response = requests.get('https://api.github.com/users/'+inputName.get())
    if not response:
        outputField.insert(1.0,'Ответ не получен')
        return
    info = json.loads(response.text)
    result = {
        "company": info["company"],
        "created_at": info["created_at"],
        "email": info["email"],
        "id": info["id"],
        "name": info["name"],
        "url": info["url"]}
    outputField.insert(1.0, json.dumps(result, indent=6))
    with open("task11_output.json", "w+") as write_file:
        json.dump(result, write_file, indent=2)

applyBtn = Button(window, text="Загрузить",command=applyBtnOnClick)
applyBtn.grid(column=2,row=1)

outputField = scrolledtext.ScrolledText(window,width=47,height=15)
outputField.grid(column=1, row=2, sticky='w', columnspan=2)


window.mainloop()
